import os
from django.shortcuts import render
from PIL import Image
from django.conf import settings
import pytesseract
import cv2
from gtts import gTTS
from googletrans import Translator
from django.core.files.storage import FileSystemStorage
from PyItT.forms import TextToSpeech, LanguageTranslate
import speech_recognition as sr
from gtts import gTTS
import urllib3


def index(request):
    import os, shutil
    folder = "D:/PYIP/PYItT/media/"
    for the_file in os.listdir(folder):
        file_path = os.path.join(folder, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            print()
    return render(request, 'index.html')


def imgtotext(request):
    return render(request, 'ImageToText.html')


def texttospeech(request):
    return render(request, 'TextToSpeech.html')


def speechtotext(request):
    return render(request, 'SpeechToText.html')


def languagetranslate(request):
    return render(request, 'LanguageTranslate.html')


def imagestitching(request):
    return render(request, 'ImageStitching.html')


def convert(request):
    if request.method == 'POST' and (request.FILES['myfile'] and request.POST['lang']):
        try:
            lang = request.POST['lang']
            myfile = request.FILES['myfile']
            fs = FileSystemStorage()
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
            uploaded_file_url.replace('/', '\\')
            url = "D:/PYIP/PYItT" + uploaded_file_url
            image = cv2.imread(url)
            tessdata_dir_config = 'C:\Program Files (x86)\Tesseract-OCR\tessdata'
            pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files (x86)/Tesseract-OCR/tesseract'
            txt = pytesseract.image_to_string(image, lang=lang, config=tessdata_dir_config)
            os.remove(url)
            text = txt
            form = "success"
        except:
            text = "Faild"
            form = "Something Wrong Please Try Again !..."
    else:
        form = "Something Wrong Please Try Again !..."
    return render(request, 'ImageToText.html', {'form': form, 'text': text})


def txtconvert(request):
    if request.method == 'POST':
        form = TextToSpeech(request.POST)
        if form.is_valid():
            try:
                text = request.POST.get("mytext")
                lang = request.POST['lang']
                tts = gTTS(text=text, lang=lang)
                tts.save("D:/PYIP/PYItT/media/index.mp3")
                form = "success"
            except:
                form = "Something Wrong Please Try Again !..."
        else:
            form = "Something Wrong Please Try Again !..."
    return render(request, 'TextToSpeech.html', {'form': form})


def langconvert(request):
    if request.method == 'POST':
        form = LanguageTranslate(request.POST)
        if form.is_valid():
            try:
                text = request.POST.get("mytext")
                lang = request.POST['lang']
                translator = Translator()
                translations = translator.translate(text, dest=lang)
                text = translations.text
                form = "success"
            except:
                text = "Faild"
                form = "Something Wrong Please Try Again !..."
        else:
            form = "Something Wrong Please Try Again !..."
    return render(request, 'LanguageTranslate.html', {'form': form, 'text': text})


def speechconvert(request):
    if request.method == 'POST':
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        r = sr.Recognizer()
        response = ""
        with sr.Microphone() as source:
            r.adjust_for_ambient_noise(source, duration=1)
            audio = r.listen(source, phrase_time_limit=5)
        try:
            response = r.recognize_google(audio)
            text = response
            form = "success"
        except:
            text = "Faild"
            form = "could not understand audio"
    else:
        form = "Something Wrong Please Try Again !..."
    return render(request, 'SpeechToText.html', {'form': form, 'text': text})


def imagestitch(request):
    if request.method == 'POST':
        try:
            myfile1 = request.FILES['myfile1']
            myfile2 = request.FILES['myfile2']
            fs = FileSystemStorage()
            filename1 = fs.save(myfile1.name, myfile1)
            filename2 = fs.save(myfile2.name, myfile2)
            uploaded_file_url1 = fs.url(filename1)
            uploaded_file_url2 = fs.url(filename2)
            uploaded_file_url1.replace('/', '\\')
            uploaded_file_url2.replace('/', '\\')
            url1 = "D:/PYIP/PYItT" + uploaded_file_url1
            url2 = "D:/PYIP/PYItT" + uploaded_file_url2
            form = "success"
        except:
            form = "Something Wrong Please Try Again !..."
    else:
        form = "Something Wrong Please Try Again !..."
    return render(request, 'ImageStitching.html', {'form': form})
