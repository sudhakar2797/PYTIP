from django import forms


class TextToSpeech(forms.Form):
    text = forms.Textarea()


class LanguageTranslate(forms.Form):
    text = forms.Textarea()
