from django.apps import AppConfig


class PyittConfig(AppConfig):
    name = 'PyItT'
